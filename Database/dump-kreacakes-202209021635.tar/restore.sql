--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE kreacakes;
--
-- Name: kreacakes; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE kreacakes WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_Indonesia.1252';


ALTER DATABASE kreacakes OWNER TO postgres;

\connect kreacakes

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: login_temp; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.login_temp AS (
	checklogin boolean,
	username character varying(100)
);


ALTER TYPE public.login_temp OWNER TO postgres;

--
-- Name: check_cart(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.check_cart(in_user_id character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
declare 
	countrow integer;
begin
		select count(*) into countrow from cart c inner join cart_items ci on ci.cart_id = c.cart_id where user_id = in_user_id and paid = false;
		raise notice 'Value: %', countrow;
	
		if(countrow > 0) then
			return true;
		else
			return false;
		end if;
	END;
$$;


ALTER FUNCTION public.check_cart(in_user_id character varying) OWNER TO postgres;

--
-- Name: check_username(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.check_username(in_username character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
declare
	count_username int;
begin
	select count(username) into count_username from account where username = in_username;
	if(count_username = 0) then
		return false;
	elsif(count_username > 0) then
		return true;
	end if;

end;
$$;


ALTER FUNCTION public.check_username(in_username character varying) OWNER TO postgres;

--
-- Name: del_clear_cart(character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.del_clear_cart(IN in_user_id character varying)
    LANGUAGE plpgsql
    AS $$
	declare 
		in_cart_id varchar;
	BEGIN
		select cart_id into in_cart_id from cart where user_id = in_user_id and paid = false;
		
		delete from cart_items where cart_id = in_cart_id;
	END;
$$;


ALTER PROCEDURE public.del_clear_cart(IN in_user_id character varying) OWNER TO postgres;

--
-- Name: delete_items(character varying, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.delete_items(IN in_items_id character varying, IN in_user_id character varying)
    LANGUAGE plpgsql
    AS $$
declare
begin
	delete from items where items_id = in_items_id and user_id = in_user_id;
end;
$$;


ALTER PROCEDURE public.delete_items(IN in_items_id character varying, IN in_user_id character varying) OWNER TO postgres;

--
-- Name: funct_login(character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.funct_login(in_username character varying, in_password character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
declare
	count_username int;
	temp_password varchar;
begin
	select count(username) into count_username from account where username = in_username or email = in_username;
	if(count_username > 0) then
		select password into temp_password from account where username = in_username or email = in_username;
		if(temp_password = in_password) then
			raise notice 'berhasil login';
			return true;
		else
			raise notice 'login gagal';
			return false;
		end if;
	elsif(count_username = 0) then
		raise notice 'akun tidak di temukan';
		return false;
	end if;

end;
$$;


ALTER FUNCTION public.funct_login(in_username character varying, in_password character varying) OWNER TO postgres;

--
-- Name: generate_id(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.generate_id(in_tablename character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
declare
   	out_id varchar;
  	id_template_temp varchar;
 	user_id_temp varchar;
 	user_id_num int;
	temp_num int;
begin
	select id_template into id_template_temp from dev_id_template where table_name  = in_tablename;

	if in_tablename = 'account' then
		select user_id into user_id_temp from account order by timestamp desc limit 1;
	elsif in_tablename = 'search_data' then
		select search_id into user_id_temp from search_data order by timestamp desc limit 1;
	elsif in_tablename = 'cart' then
		select cart_id into user_id_temp from cart order by timestamp desc limit 1;
	elsif in_tablename = 'category' then
		select category_id into user_id_temp from category order by timestamp desc limit 1;
	elsif in_tablename = 'items' then
		select items_id into user_id_temp from items order by timestamp desc limit 1;
	elsif in_tablename = 'order_history' then
		select order_id into user_id_temp from order_history order by timestamp desc limit 1;
	elsif in_tablename = 'payment' then
		select payment_id into user_id_temp from payment order by timestamp desc limit 1;
	elsif in_tablename = 'rating' then
		select rating_id into user_id_temp from rating sd order by timestamp desc limit 1;
	elsif in_tablename = 'voucher' then
		select voucher_id into user_id_temp from voucher order by timestamp desc limit 1;
	elsif in_tablename = 'cart_items' then
		select cart_items_id into user_id_temp from cart_items order by timestamp desc limit 1;
	end if;
	select split_part(user_id_temp, '_', 2) into user_id_num; 

	if (user_id_temp IS NULL) then
		out_id := id_template_temp || '_1';
   		return out_id;
	else
		select (user_id_num + 1) into temp_num;
		out_id := id_template_temp || '_' || temp_num;
   		return out_id;
	end if;

end;
$$;


ALTER FUNCTION public.generate_id(in_tablename character varying) OWNER TO postgres;

--
-- Name: get_account(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_account(in_username character varying) RETURNS json
    LANGUAGE plpgsql
    AS $$
declare account_details json;
begin 
	 
	select row_to_json(t) into account_details from account t where username = in_username;

	return account_details;
end;
$$;


ALTER FUNCTION public.get_account(in_username character varying) OWNER TO postgres;

--
-- Name: ins_cart_items(character varying, character varying, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.ins_cart_items(IN in_user_id character varying, IN in_items_id character varying, IN in_quantity integer)
    LANGUAGE plpgsql
    AS $$
declare
	in_cart_items_id varchar;
	in_cart_id varchar;
begin
	select generate_id into in_cart_items_id from generate_id('cart_items') ;
	select cart_id into in_cart_id from cart where user_id = in_user_id and paid = false;

	insert into cart_items(cart_items_id, cart_id, items_id, quantity) values (in_cart_items_id, in_cart_id, in_items_id, in_quantity);
end;
$$;


ALTER PROCEDURE public.ins_cart_items(IN in_user_id character varying, IN in_items_id character varying, IN in_quantity integer) OWNER TO postgres;

--
-- Name: ins_items(character varying, integer, character varying, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.ins_items(IN in_user_id character varying, IN in_price integer, IN in_category_id character varying, IN in_items_name character varying)
    LANGUAGE plpgsql
    AS $$
declare
	in_items_id varchar;
	in_role varchar;
begin
	select role into in_role from account where user_id = in_user_id;
	if(in_role = 'seller') then
		select generate_id into in_items_id from generate_id('items'); 
		insert into items(items_id, user_id, price, category_id, sold_amount, items_name) values (in_items_id, in_user_id, in_price, in_category_id, 0, in_items_name);
	end if;
end;
$$;


ALTER PROCEDURE public.ins_items(IN in_user_id character varying, IN in_price integer, IN in_category_id character varying, IN in_items_name character varying) OWNER TO postgres;

--
-- Name: ins_register(character varying, character varying, character varying, character varying, integer, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.ins_register(IN in_username character varying, IN in_password character varying, IN in_email character varying, IN in_role character varying, IN in_balance integer, IN in_phone character varying)
    LANGUAGE plpgsql
    AS $$
declare idType varchar;
temp_check_username boolean;
in_cart_id varchar;
begin 
	select generate_id into idType from generate_id('account') ;
	select generate_id into in_cart_id from generate_id('cart') ;
	select check_username into temp_check_username from check_username(in_username);

	if(temp_check_username = false) then
		raise notice 'Value: %', temp_check_username;
		insert into account (user_id, username, password, email, role, balance, phone) values (idType, in_username, in_password, in_email, in_role, in_balance, in_phone);
		if(in_role = 'customer') then 	
			insert into cart (cart_id, user_id) values (in_cart_id, idType);
		end if;
	end if;
	
end; $$;


ALTER PROCEDURE public.ins_register(IN in_username character varying, IN in_password character varying, IN in_email character varying, IN in_role character varying, IN in_balance integer, IN in_phone character varying) OWNER TO postgres;

--
-- Name: put_pay_cart(character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.put_pay_cart(IN in_user_id character varying)
    LANGUAGE plpgsql
    AS $$
	declare 
		in_cart_id varchar;
		gen_cart_id varchar;
		gen_order_id varchar;
	BEGIN
		select cart_id into in_cart_id from cart where user_id = in_user_id;
	
		update cart set paid = true where user_id = in_user_id and paid = false;
	
		select generate_id into gen_cart_id from generate_id('cart'); 
		select generate_id into gen_order_id from generate_id('order_history') ;
	
		insert into cart(cart_id, user_id, paid) values (gen_cart_id, in_user_id, false);
		insert into order_history (order_id, user_id, cart_id) values (gen_order_id, in_user_id, in_cart_id);
	END;
$$;


ALTER PROCEDURE public.put_pay_cart(IN in_user_id character varying) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account (
    user_id character varying NOT NULL,
    username character varying,
    password character varying,
    email character varying,
    role character varying,
    balance integer,
    "timestamp" timestamp without time zone DEFAULT now(),
    phone character varying
);


ALTER TABLE public.account OWNER TO postgres;

--
-- Name: cart; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cart (
    cart_id character varying NOT NULL,
    user_id character varying NOT NULL,
    paid boolean DEFAULT false,
    "timestamp" timestamp without time zone DEFAULT now()
);


ALTER TABLE public.cart OWNER TO postgres;

--
-- Name: cart_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cart_items (
    cart_items_id character varying NOT NULL,
    cart_id character varying,
    items_id character varying,
    "timestamp" timestamp without time zone DEFAULT now(),
    quantity integer
);


ALTER TABLE public.cart_items OWNER TO postgres;

--
-- Name: category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.category (
    category_id character varying NOT NULL,
    category_name character varying,
    "timestamp" timestamp without time zone DEFAULT now()
);


ALTER TABLE public.category OWNER TO postgres;

--
-- Name: dev_id_template; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dev_id_template (
    data_id character varying NOT NULL,
    table_name character varying,
    id_template character varying
);


ALTER TABLE public.dev_id_template OWNER TO postgres;

--
-- Name: items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.items (
    items_id character varying NOT NULL,
    user_id character varying,
    price integer,
    category_id character varying,
    sold_amount integer,
    "timestamp" timestamp without time zone DEFAULT now(),
    items_name character varying
);


ALTER TABLE public.items OWNER TO postgres;

--
-- Name: order_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_history (
    order_id character varying NOT NULL,
    user_id character varying,
    cart_id character varying,
    "timestamp" timestamp without time zone DEFAULT now()
);


ALTER TABLE public.order_history OWNER TO postgres;

--
-- Name: payment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment (
    payment_id character varying NOT NULL,
    user_id character varying,
    order_id character varying,
    "timestamp" timestamp without time zone DEFAULT now()
);


ALTER TABLE public.payment OWNER TO postgres;

--
-- Name: rating; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rating (
    rating_id character varying NOT NULL,
    items_id character varying,
    rating_value integer,
    "timestamp" timestamp without time zone DEFAULT now()
);


ALTER TABLE public.rating OWNER TO postgres;

--
-- Name: search_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.search_data (
    search_id character varying NOT NULL,
    search_word character varying,
    time_stamp timestamp without time zone,
    user_id character varying,
    "timestamp" timestamp without time zone DEFAULT now()
);


ALTER TABLE public.search_data OWNER TO postgres;

--
-- Name: voucher; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.voucher (
    voucher_id character varying NOT NULL,
    voucher_code character varying,
    voucher_amount numeric,
    "timestamp" timestamp without time zone DEFAULT now()
);


ALTER TABLE public.voucher OWNER TO postgres;

--
-- Name: wishlist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wishlist (
    wishlist_id character varying NOT NULL,
    items_id character varying,
    user_id character varying
);


ALTER TABLE public.wishlist OWNER TO postgres;

--
-- Data for Name: account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account (user_id, username, password, email, role, balance, "timestamp", phone) FROM stdin;
\.
COPY public.account (user_id, username, password, email, role, balance, "timestamp", phone) FROM '$$PATH$$/3407.dat';

--
-- Data for Name: cart; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cart (cart_id, user_id, paid, "timestamp") FROM stdin;
\.
COPY public.cart (cart_id, user_id, paid, "timestamp") FROM '$$PATH$$/3414.dat';

--
-- Data for Name: cart_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cart_items (cart_items_id, cart_id, items_id, "timestamp", quantity) FROM stdin;
\.
COPY public.cart_items (cart_items_id, cart_id, items_id, "timestamp", quantity) FROM '$$PATH$$/3417.dat';

--
-- Data for Name: category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.category (category_id, category_name, "timestamp") FROM stdin;
\.
COPY public.category (category_id, category_name, "timestamp") FROM '$$PATH$$/3410.dat';

--
-- Data for Name: dev_id_template; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dev_id_template (data_id, table_name, id_template) FROM stdin;
\.
COPY public.dev_id_template (data_id, table_name, id_template) FROM '$$PATH$$/3416.dat';

--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.items (items_id, user_id, price, category_id, sold_amount, "timestamp", items_name) FROM stdin;
\.
COPY public.items (items_id, user_id, price, category_id, sold_amount, "timestamp", items_name) FROM '$$PATH$$/3409.dat';

--
-- Data for Name: order_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_history (order_id, user_id, cart_id, "timestamp") FROM stdin;
\.
COPY public.order_history (order_id, user_id, cart_id, "timestamp") FROM '$$PATH$$/3412.dat';

--
-- Data for Name: payment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment (payment_id, user_id, order_id, "timestamp") FROM stdin;
\.
COPY public.payment (payment_id, user_id, order_id, "timestamp") FROM '$$PATH$$/3413.dat';

--
-- Data for Name: rating; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rating (rating_id, items_id, rating_value, "timestamp") FROM stdin;
\.
COPY public.rating (rating_id, items_id, rating_value, "timestamp") FROM '$$PATH$$/3411.dat';

--
-- Data for Name: search_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.search_data (search_id, search_word, time_stamp, user_id, "timestamp") FROM stdin;
\.
COPY public.search_data (search_id, search_word, time_stamp, user_id, "timestamp") FROM '$$PATH$$/3408.dat';

--
-- Data for Name: voucher; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.voucher (voucher_id, voucher_code, voucher_amount, "timestamp") FROM stdin;
\.
COPY public.voucher (voucher_id, voucher_code, voucher_amount, "timestamp") FROM '$$PATH$$/3415.dat';

--
-- Data for Name: wishlist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.wishlist (wishlist_id, items_id, user_id) FROM stdin;
\.
COPY public.wishlist (wishlist_id, items_id, user_id) FROM '$$PATH$$/3418.dat';

--
-- Name: account account_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_pk PRIMARY KEY (user_id);


--
-- Name: cart_items cart_items_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT cart_items_pk PRIMARY KEY (cart_items_id);


--
-- Name: cart cart_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart
    ADD CONSTRAINT cart_pk PRIMARY KEY (cart_id);


--
-- Name: category category_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT category_pk PRIMARY KEY (category_id);


--
-- Name: dev_id_template dev_id_template_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dev_id_template
    ADD CONSTRAINT dev_id_template_pk PRIMARY KEY (data_id);


--
-- Name: items items_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pk PRIMARY KEY (items_id);


--
-- Name: order_history order_history_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_history
    ADD CONSTRAINT order_history_pk PRIMARY KEY (order_id);


--
-- Name: payment payment_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT payment_pk PRIMARY KEY (payment_id);


--
-- Name: rating rating_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rating
    ADD CONSTRAINT rating_pk PRIMARY KEY (rating_id);


--
-- Name: search_data search_data_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.search_data
    ADD CONSTRAINT search_data_pk PRIMARY KEY (search_id);


--
-- Name: voucher voucher_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.voucher
    ADD CONSTRAINT voucher_pk PRIMARY KEY (voucher_id);


--
-- Name: wishlist wishlist_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wishlist
    ADD CONSTRAINT wishlist_pk PRIMARY KEY (wishlist_id);


--
-- Name: cart cart_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart
    ADD CONSTRAINT cart_fk FOREIGN KEY (user_id) REFERENCES public.account(user_id);


--
-- Name: items items_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_fk FOREIGN KEY (category_id) REFERENCES public.category(category_id);


--
-- Name: items items_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_fk_1 FOREIGN KEY (user_id) REFERENCES public.account(user_id);


--
-- Name: order_history order_history_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_history
    ADD CONSTRAINT order_history_fk FOREIGN KEY (user_id) REFERENCES public.account(user_id);


--
-- Name: order_history order_history_fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_history
    ADD CONSTRAINT order_history_fk1 FOREIGN KEY (cart_id) REFERENCES public.cart(cart_id);


--
-- Name: payment payment_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT payment_fk FOREIGN KEY (user_id) REFERENCES public.account(user_id);


--
-- Name: payment payment_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT payment_fk_1 FOREIGN KEY (order_id) REFERENCES public.order_history(order_id);


--
-- Name: rating rating_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rating
    ADD CONSTRAINT rating_fk FOREIGN KEY (items_id) REFERENCES public.items(items_id);


--
-- Name: search_data search_data_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.search_data
    ADD CONSTRAINT search_data_fk FOREIGN KEY (user_id) REFERENCES public.account(user_id);


--
-- Name: wishlist wishlist_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wishlist
    ADD CONSTRAINT wishlist_fk FOREIGN KEY (user_id) REFERENCES public.account(user_id);


--
-- Name: wishlist wishlist_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wishlist
    ADD CONSTRAINT wishlist_fk_1 FOREIGN KEY (items_id) REFERENCES public.items(items_id);


--
-- PostgreSQL database dump complete
--

